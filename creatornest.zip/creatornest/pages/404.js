import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../components/Navbar'

export default function NotFound() {
  return (
    <>
      <Head><title>Page Not Found — CreatorNest</title></Head>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center text-center px-6">
        <div>
          <p className="font-mono text-8xl font-bold text-border mb-6">404</p>
          <h1 className="font-display text-3xl font-bold mb-3">Page not found</h1>
          <p className="text-muted font-body mb-8">This page doesn't exist or has been moved.</p>
          <Link href="/" className="bg-charcoal text-cream px-6 py-3 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors">
            Go back home
          </Link>
        </div>
      </main>
    </>
  )
}
