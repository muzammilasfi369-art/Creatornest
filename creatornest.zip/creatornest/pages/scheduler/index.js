import Head from 'next/head'
import { useState } from 'react'
import Link from 'next/link'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const platforms = [
  { name: 'YouTube', color: 'bg-red-100 text-red-700 border-red-200', icon: '▶️' },
  { name: 'Instagram', color: 'bg-purple-100 text-purple-700 border-purple-200', icon: '📸' },
  { name: 'TikTok', color: 'bg-pink-100 text-pink-700 border-pink-200', icon: '🎵' },
  { name: 'Facebook', color: 'bg-blue-100 text-blue-700 border-blue-200', icon: '📘' },
  { name: 'Twitter / X', color: 'bg-sky-100 text-sky-700 border-sky-200', icon: '🐦' },
  { name: 'LinkedIn', color: 'bg-indigo-100 text-indigo-700 border-indigo-200', icon: '💼' },
  { name: 'Pinterest', color: 'bg-rose-100 text-rose-700 border-rose-200', icon: '📌' },
  { name: 'Snapchat', color: 'bg-yellow-100 text-yellow-700 border-yellow-200', icon: '👻' },
]

const demoScheduled = [
  { platform: 'YouTube', icon: '▶️', color: 'bg-red-100 border-red-200', title: 'New vlog - A day in my life', date: 'Today', time: '10:00 AM', status: 'Scheduled' },
  { platform: 'Instagram', icon: '📸', color: 'bg-purple-100 border-purple-200', title: 'Behind the scenes reel', date: 'Today', time: '12:30 PM', status: 'Scheduled' },
  { platform: 'TikTok', icon: '🎵', color: 'bg-pink-100 border-pink-200', title: 'Quick tips for creators #5', date: 'Tomorrow', time: '06:00 PM', status: 'Draft' },
  { platform: 'Twitter / X', icon: '🐦', color: 'bg-sky-100 border-sky-200', title: 'Thread: My creator journey', date: 'Tomorrow', time: '08:00 PM', status: 'Scheduled' },
  { platform: 'LinkedIn', icon: '💼', color: 'bg-indigo-100 border-indigo-200', title: 'How I grew to 100K subscribers', date: 'Friday', time: '09:00 AM', status: 'Scheduled' },
]

export default function Scheduler() {
  const [selectedPlatforms, setSelectedPlatforms] = useState([])
  const [postTitle, setPostTitle] = useState('')
  const [postContent, setPostContent] = useState('')
  const [schedDate, setSchedDate] = useState('')
  const [schedTime, setSchedTime] = useState('')
  const [scheduled, setScheduled] = useState(demoScheduled)
  const [success, setSuccess] = useState(false)

  const togglePlatform = (p) => {
    setSelectedPlatforms(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p])
  }

  const handleSchedule = () => {
    if (!postTitle || selectedPlatforms.length === 0) return
    const newPosts = selectedPlatforms.map(p => {
      const plat = platforms.find(pl => pl.name === p)
      return {
        platform: p,
        icon: plat?.icon || '📱',
        color: plat?.color?.replace('text-', 'border-').split(' ').filter(c => c.startsWith('bg-') || c.startsWith('border-')).join(' ') || 'bg-gray-100 border-gray-200',
        title: postTitle,
        date: schedDate || 'Unscheduled',
        time: schedTime || '--:--',
        status: schedDate ? 'Scheduled' : 'Draft',
      }
    })
    setScheduled(prev => [...newPosts, ...prev])
    setPostTitle('')
    setPostContent('')
    setSelectedPlatforms([])
    setSchedDate('')
    setSchedTime('')
    setSuccess(true)
    setTimeout(() => setSuccess(false), 3000)
  }

  return (
    <>
      <Head><title>Social Media Scheduler — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <Link href="/" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Home</Link>
            <h1 className="font-display text-4xl font-bold mt-4 mb-2">Social Scheduler 📅</h1>
            <p className="text-muted font-body">Schedule posts to all your platforms from one dashboard.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Compose */}
            <div className="bg-white border border-border rounded-2xl p-8">
              <h2 className="font-display text-xl font-semibold mb-6">Create Post</h2>

              <div className="mb-5">
                <label className="block text-sm font-semibold font-body mb-3">Select Platforms</label>
                <div className="grid grid-cols-2 gap-2">
                  {platforms.map(p => (
                    <button key={p.name} onClick={() => togglePlatform(p.name)}
                      className={`flex items-center gap-2 px-3 py-2.5 rounded-xl border text-sm font-body transition-all ${
                        selectedPlatforms.includes(p.name)
                          ? 'bg-charcoal text-cream border-charcoal'
                          : 'border-border text-muted hover:border-charcoal'
                      }`}>
                      <span>{p.icon}</span> {p.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mb-4">
                <label className="block text-sm font-semibold font-body mb-2">Post Title</label>
                <input value={postTitle} onChange={e => setPostTitle(e.target.value)}
                  placeholder="e.g. Morning Routine 2025"
                  className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
              </div>

              <div className="mb-4">
                <label className="block text-sm font-semibold font-body mb-2">Caption / Description</label>
                <textarea value={postContent} onChange={e => setPostContent(e.target.value)}
                  placeholder="Write your caption here..."
                  className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body resize-none h-28 focus:outline-none focus:border-charcoal transition-colors" />
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-sm font-semibold font-body mb-2">Date</label>
                  <input type="date" value={schedDate} onChange={e => setSchedDate(e.target.value)}
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
                </div>
                <div>
                  <label className="block text-sm font-semibold font-body mb-2">Time</label>
                  <input type="time" value={schedTime} onChange={e => setSchedTime(e.target.value)}
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
                </div>
              </div>

              {success && (
                <div className="mb-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm font-body">
                  ✓ Post scheduled successfully!
                </div>
              )}

              <button onClick={handleSchedule} disabled={!postTitle || selectedPlatforms.length === 0}
                className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                Schedule Post →
              </button>
            </div>

            {/* Queue */}
            <div>
              <h2 className="font-display text-xl font-semibold mb-6">Scheduled Queue</h2>
              <div className="space-y-3">
                {scheduled.map((post, i) => (
                  <div key={i} className={`border rounded-xl px-4 py-4 ${post.color}`}>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <span>{post.icon}</span>
                        <span className="text-xs font-semibold font-mono">{post.platform}</span>
                      </div>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-mono ${
                        post.status === 'Scheduled' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>{post.status}</span>
                    </div>
                    <p className="text-sm text-charcoal mt-2 font-body font-medium">{post.title}</p>
                    <p className="text-xs text-muted font-mono mt-1">{post.date} · {post.time}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
