import Head from 'next/head'
import Link from 'next/link'
import { useState } from 'react'
import Navbar from '../../components/Navbar'

export default function Signup() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  return (
    <>
      <Head><title>Get Started Free — CreatorNest</title></Head>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center px-6 pt-16">
        <div className="w-full max-w-md">
          <div className="text-center mb-10">
            <h1 className="font-display text-4xl font-bold mb-2">Start for free</h1>
            <p className="text-muted font-body text-sm">No credit card required. Set up in 60 seconds.</p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-8">
            <div className="mb-4">
              <label className="block text-sm font-semibold font-body mb-2">Full Name</label>
              <input type="text" value={name} onChange={e => setName(e.target.value)}
                placeholder="Your name"
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
            </div>
            <div className="mb-4">
              <label className="block text-sm font-semibold font-body mb-2">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
            </div>
            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-2">Password</label>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder="Create a strong password"
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
            </div>
            <button className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors">
              Create Free Account
            </button>
            <p className="text-center text-xs text-muted font-body mt-4">
              By signing up, you agree to our{' '}
              <Link href="#" className="underline">Terms of Service</Link> and{' '}
              <Link href="#" className="underline">Privacy Policy</Link>
            </p>
            <p className="text-center text-sm text-muted font-body mt-6">
              Already have an account?{' '}
              <Link href="/login" className="text-charcoal font-semibold hover:underline">Sign in</Link>
            </p>
          </div>
        </div>
      </main>
    </>
  )
}
