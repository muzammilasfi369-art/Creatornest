import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

const tools = [
  {
    icon: '✍️',
    title: 'AI Caption Writer',
    desc: 'Generate scroll-stopping captions for Instagram, TikTok, YouTube and more in seconds.',
    href: '/tools/caption-writer',
    tag: 'AI Powered',
  },
  {
    icon: '#️⃣',
    title: 'Hashtag Generator',
    desc: 'Find the best-performing hashtags for your niche to maximize reach and discoverability.',
    href: '/tools/hashtag-generator',
    tag: 'Smart',
  },
  {
    icon: '🖼️',
    title: 'Thumbnail Maker',
    desc: 'Design eye-catching YouTube thumbnails with drag-and-drop ease. No design skills needed.',
    href: '/tools/thumbnail-maker',
    tag: 'Design',
  },
  {
    icon: '📅',
    title: 'Social Scheduler',
    desc: 'Schedule posts to YouTube, Instagram, Facebook, TikTok & Twitter all from one dashboard.',
    href: '/scheduler',
    tag: 'Multi-Platform',
  },
  {
    icon: '📊',
    title: 'Analytics Dashboard',
    desc: 'Track all your metrics across every platform in one beautiful, unified dashboard.',
    href: '/analytics',
    tag: 'Insights',
  },
  {
    icon: '🔗',
    title: 'Link in Bio Builder',
    desc: 'Create a stunning link-in-bio page that converts your followers into fans and customers.',
    href: '/tools/link-in-bio',
    tag: 'Growth',
  },
]

const platforms = ['YouTube', 'Instagram', 'TikTok', 'Facebook', 'Twitter / X', 'LinkedIn', 'Pinterest', 'Snapchat']

const testimonials = [
  {
    name: 'Aisha K.',
    role: 'Lifestyle Creator · 280K followers',
    text: 'CreatorNest saved me 10 hours a week. I schedule everything in one place and the AI captions are genuinely good.',
  },
  {
    name: 'Marcus T.',
    role: 'YouTube Tech Reviewer · 500K subs',
    text: 'The analytics dashboard finally made me understand what content works. My channel grew 40% in 3 months.',
  },
  {
    name: 'Priya S.',
    role: 'Food Blogger · 120K followers',
    text: 'The hashtag tool is insane. I went from 2K to 15K reach per post in just a few weeks.',
  },
]

const pricingPlans = [
  {
    name: 'Free',
    price: '$0',
    period: 'forever',
    desc: 'Perfect to get started',
    features: ['5 AI captions/month', 'Hashtag generator (basic)', '1 scheduled post/day', 'Link in bio page', 'Community support'],
    cta: 'Start Free',
    highlight: false,
  },
  {
    name: 'Pro',
    price: '$12',
    period: 'per month',
    desc: 'For serious creators',
    features: ['Unlimited AI captions', 'Advanced hashtag analytics', '50 scheduled posts/day', 'Thumbnail maker', 'Analytics dashboard', 'Priority support'],
    cta: 'Start Pro Trial',
    highlight: true,
  },
  {
    name: 'Agency',
    price: '$39',
    period: 'per month',
    desc: 'For teams & agencies',
    features: ['Everything in Pro', 'Manage 10+ accounts', 'Team collaboration', 'White-label reports', 'API access', 'Dedicated support'],
    cta: 'Contact Sales',
    highlight: false,
  },
]

export default function Home() {
  return (
    <>
      <Head>
        <title>CreatorNest — All-in-One Platform for Content Creators</title>
        <meta name="description" content="Schedule posts, write AI captions, generate hashtags, design thumbnails, and track analytics — all in one place." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <Navbar />

      <main>
        {/* ── HERO ── */}
        <section className="min-h-screen flex flex-col items-center justify-center text-center px-6 pt-24 pb-16 relative overflow-hidden">
          {/* Subtle grid background */}
          <div className="absolute inset-0 opacity-30"
            style={{backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)', backgroundSize: '60px 60px'}}
          />

          <div className="relative z-10 max-w-4xl mx-auto">
            <span className="inline-block bg-highlight border border-border text-charcoal text-xs font-mono px-4 py-1.5 rounded-full mb-8 tracking-wider uppercase animate-fade-in opacity-0 animate-delay-100">
              Built for the Creator Economy
            </span>

            <h1 className="font-display text-5xl md:text-7xl font-bold text-charcoal leading-tight mb-6 animate-fade-up opacity-0 animate-delay-200">
              Every tool a creator
              <br />
              <span className="text-muted">will ever need.</span>
            </h1>

            <p className="text-lg md:text-xl text-muted max-w-2xl mx-auto mb-10 leading-relaxed font-body animate-fade-up opacity-0 animate-delay-300">
              Schedule posts, write AI captions, generate hashtags, design thumbnails, and track your analytics — all from one clean, powerful dashboard.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-up opacity-0 animate-delay-400">
              <Link href="/signup" className="bg-charcoal text-cream px-8 py-3.5 rounded-full text-sm font-medium hover:bg-accent transition-all hover:shadow-lg font-body">
                Get Started — It's Free
              </Link>
              <Link href="/tools" className="bg-white border border-border text-charcoal px-8 py-3.5 rounded-full text-sm font-medium hover:bg-highlight transition-all font-body">
                Explore Tools →
              </Link>
            </div>

            <p className="text-xs text-muted mt-6 font-body animate-fade-in opacity-0 animate-delay-500">
              No credit card required · Free forever plan available
            </p>
          </div>

          {/* Platform pills */}
          <div className="relative z-10 mt-16 flex flex-wrap justify-center gap-2 max-w-2xl mx-auto animate-fade-up opacity-0 animate-delay-500">
            {platforms.map(p => (
              <span key={p} className="bg-white border border-border text-muted text-xs px-3 py-1.5 rounded-full font-body">
                {p}
              </span>
            ))}
          </div>
        </section>

        {/* ── STATS ── */}
        <section className="bg-charcoal text-cream py-14">
          <div className="max-w-5xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { num: '50K+', label: 'Active Creators' },
              { num: '2M+', label: 'Posts Scheduled' },
              { num: '8', label: 'Platforms Supported' },
              { num: '10hrs', label: 'Saved Per Creator/Week' },
            ].map(s => (
              <div key={s.label}>
                <div className="font-display text-3xl md:text-4xl font-bold">{s.num}</div>
                <div className="text-sm text-gray-400 mt-1 font-body">{s.label}</div>
              </div>
            ))}
          </div>
        </section>

        {/* ── TOOLS ── */}
        <section className="py-24 px-6" id="tools">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <span className="text-xs font-mono text-muted uppercase tracking-widest">What's Inside</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mt-3">Your creator toolkit</h2>
              <p className="text-muted mt-4 max-w-xl mx-auto font-body">Everything you need to create, grow, and monetize — no switching between 10 different apps.</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {tools.map((tool) => (
                <Link key={tool.title} href={tool.href}>
                  <div className="tool-card bg-white border border-border rounded-2xl p-8 cursor-pointer h-full">
                    <div className="flex items-start justify-between mb-5">
                      <span className="text-3xl">{tool.icon}</span>
                      <span className="text-xs bg-highlight text-muted px-3 py-1 rounded-full font-mono">{tool.tag}</span>
                    </div>
                    <h3 className="font-display text-xl font-semibold mb-2">{tool.title}</h3>
                    <p className="text-sm text-muted leading-relaxed font-body">{tool.desc}</p>
                    <div className="mt-6 text-sm text-charcoal font-medium font-body flex items-center gap-1">
                      Try it free <span>→</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* ── SCHEDULER HIGHLIGHT ── */}
        <section className="py-24 px-6 bg-highlight">
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div>
              <span className="text-xs font-mono text-muted uppercase tracking-widest">Multi-Platform Scheduler</span>
              <h2 className="font-display text-4xl font-bold mt-3 mb-5">
                Post everywhere.<br />Manage from one place.
              </h2>
              <p className="text-muted font-body leading-relaxed mb-8">
                Plan your entire content calendar, write posts with AI assistance, and auto-publish to YouTube, Instagram, Facebook, TikTok, Twitter, LinkedIn, and more — all from a single, clean dashboard.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Drag & drop content calendar',
                  'Best-time-to-post suggestions',
                  'Bulk schedule weeks in advance',
                  'Auto-resize for each platform',
                ].map(f => (
                  <li key={f} className="flex items-center gap-3 text-sm font-body">
                    <span className="w-5 h-5 bg-charcoal text-cream rounded-full flex items-center justify-center text-xs flex-shrink-0">✓</span>
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="/scheduler" className="bg-charcoal text-cream px-6 py-3 rounded-full text-sm font-medium font-body inline-block hover:bg-accent transition-colors">
                Explore Scheduler →
              </Link>
            </div>

            {/* Visual mockup */}
            <div className="bg-white border border-border rounded-2xl p-6 shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-3 h-3 rounded-full bg-red-300" />
                <div className="w-3 h-3 rounded-full bg-yellow-300" />
                <div className="w-3 h-3 rounded-full bg-green-300" />
                <span className="text-xs text-muted font-mono ml-2">scheduler.creatornest.app</span>
              </div>
              <div className="grid grid-cols-7 gap-1 mb-4">
                {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => (
                  <div key={d} className="text-center text-xs text-muted font-mono py-1">{d}</div>
                ))}
              </div>
              <div className="space-y-2">
                {[
                  { platform: 'YouTube', time: '10:00 AM', title: 'New vlog - Day in my life', color: 'bg-red-100 border-red-200' },
                  { platform: 'Instagram', time: '12:30 PM', title: 'Behind the scenes reel', color: 'bg-purple-100 border-purple-200' },
                  { platform: 'TikTok', time: '06:00 PM', title: 'Quick tips for creators', color: 'bg-pink-100 border-pink-200' },
                  { platform: 'Twitter', time: '08:00 PM', title: 'Thread: my creator journey', color: 'bg-blue-100 border-blue-200' },
                ].map(p => (
                  <div key={p.platform} className={`border rounded-xl px-4 py-3 ${p.color}`}>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-semibold font-mono">{p.platform}</span>
                      <span className="text-xs text-muted font-mono">{p.time}</span>
                    </div>
                    <p className="text-xs text-charcoal mt-1 font-body">{p.title}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* ── TESTIMONIALS ── */}
        <section className="py-24 px-6">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <span className="text-xs font-mono text-muted uppercase tracking-widest">Creator Stories</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mt-3">Loved by creators worldwide</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {testimonials.map(t => (
                <div key={t.name} className="bg-white border border-border rounded-2xl p-8">
                  <p className="text-charcoal font-body leading-relaxed mb-6">"{t.text}"</p>
                  <div>
                    <div className="font-semibold text-sm font-body">{t.name}</div>
                    <div className="text-xs text-muted mt-0.5 font-body">{t.role}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── PRICING ── */}
        <section className="py-24 px-6 bg-highlight" id="pricing">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-16">
              <span className="text-xs font-mono text-muted uppercase tracking-widest">Simple Pricing</span>
              <h2 className="font-display text-4xl md:text-5xl font-bold mt-3">Start free, grow on your terms</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
              {pricingPlans.map(plan => (
                <div key={plan.name} className={`rounded-2xl p-8 ${
                  plan.highlight
                    ? 'bg-charcoal text-cream ring-2 ring-charcoal scale-105'
                    : 'bg-white border border-border'
                }`}>
                  <div className="mb-6">
                    <h3 className={`font-display text-xl font-bold ${plan.highlight ? 'text-cream' : 'text-charcoal'}`}>{plan.name}</h3>
                    <p className={`text-sm mt-1 font-body ${plan.highlight ? 'text-gray-400' : 'text-muted'}`}>{plan.desc}</p>
                  </div>
                  <div className="mb-8">
                    <span className={`font-display text-4xl font-bold ${plan.highlight ? 'text-cream' : 'text-charcoal'}`}>{plan.price}</span>
                    <span className={`text-sm ml-1 font-body ${plan.highlight ? 'text-gray-400' : 'text-muted'}`}>/{plan.period}</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map(f => (
                      <li key={f} className={`flex items-center gap-3 text-sm font-body ${plan.highlight ? 'text-gray-300' : 'text-muted'}`}>
                        <span className={`flex-shrink-0 w-4 h-4 rounded-full flex items-center justify-center text-xs ${plan.highlight ? 'bg-white text-charcoal' : 'bg-charcoal text-cream'}`}>✓</span>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Link href="/signup" className={`block text-center py-3 rounded-full text-sm font-medium font-body transition-colors ${
                    plan.highlight
                      ? 'bg-white text-charcoal hover:bg-gray-100'
                      : 'bg-charcoal text-cream hover:bg-accent'
                  }`}>
                    {plan.cta}
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── CTA BANNER ── */}
        <section className="py-24 px-6">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-6xl font-bold mb-6">
              Ready to grow<br />your audience?
            </h2>
            <p className="text-muted font-body text-lg mb-10">
              Join 50,000+ creators who use CreatorNest to save time and grow faster.
            </p>
            <Link href="/signup" className="bg-charcoal text-cream px-10 py-4 rounded-full text-sm font-medium font-body hover:bg-accent transition-all hover:shadow-xl inline-block">
              Create Your Free Account
            </Link>
          </div>
        </section>
      </main>

      <Footer />
    </>
  )
}
