import Head from 'next/head'
import Link from 'next/link'
import { useState } from 'react'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const themes = [
  { name: 'Minimal White', bg: 'bg-white', text: 'text-gray-900', btn: 'bg-gray-900 text-white', preview: 'bg-white border border-gray-200' },
  { name: 'Dark Mode', bg: 'bg-gray-900', text: 'text-white', btn: 'bg-white text-gray-900', preview: 'bg-gray-900' },
  { name: 'Soft Purple', bg: 'bg-purple-50', text: 'text-purple-900', btn: 'bg-purple-600 text-white', preview: 'bg-purple-50' },
  { name: 'Warm Cream', bg: 'bg-amber-50', text: 'text-amber-900', btn: 'bg-amber-800 text-white', preview: 'bg-amber-50' },
]

export default function LinkInBio() {
  const [theme, setTheme] = useState(0)
  const [name, setName] = useState('Your Name')
  const [bio, setBio] = useState('Content Creator · Sharing tips and inspiration')
  const [links, setLinks] = useState([
    { label: 'My YouTube Channel', url: 'https://youtube.com' },
    { label: 'Instagram', url: 'https://instagram.com' },
    { label: 'My Latest Blog Post', url: 'https://blog.com' },
  ])

  const addLink = () => setLinks(prev => [...prev, { label: 'New Link', url: '' }])
  const updateLink = (i, field, val) => setLinks(prev => prev.map((l, idx) => idx === i ? { ...l, [field]: val } : l))
  const removeLink = (i) => setLinks(prev => prev.filter((_, idx) => idx !== i))

  const t = themes[theme]

  return (
    <>
      <Head><title>Link in Bio Builder — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-12">
            <Link href="/tools" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Tools</Link>
            <h1 className="font-display text-4xl font-bold mt-4 mb-2">Link in Bio Builder 🔗</h1>
            <p className="text-muted font-body">Create a stunning link page for all your social profiles.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {/* Editor */}
            <div className="space-y-6">
              {/* Theme */}
              <div className="bg-white border border-border rounded-2xl p-6">
                <h2 className="font-semibold text-sm font-body mb-4">Choose Theme</h2>
                <div className="grid grid-cols-2 gap-3">
                  {themes.map((th, i) => (
                    <button key={th.name} onClick={() => setTheme(i)}
                      className={`p-3 rounded-xl border text-left transition-all ${i === theme ? 'border-charcoal ring-1 ring-charcoal' : 'border-border hover:border-charcoal'}`}>
                      <div className={`h-8 rounded-lg mb-2 ${th.preview}`} />
                      <span className="text-xs font-body font-medium">{th.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Profile */}
              <div className="bg-white border border-border rounded-2xl p-6">
                <h2 className="font-semibold text-sm font-body mb-4">Profile Info</h2>
                <div className="space-y-3">
                  <input value={name} onChange={e => setName(e.target.value)}
                    placeholder="Your Name"
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
                  <textarea value={bio} onChange={e => setBio(e.target.value)}
                    placeholder="Short bio..."
                    className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body resize-none h-20 focus:outline-none focus:border-charcoal transition-colors" />
                </div>
              </div>

              {/* Links */}
              <div className="bg-white border border-border rounded-2xl p-6">
                <h2 className="font-semibold text-sm font-body mb-4">Your Links</h2>
                <div className="space-y-3 mb-4">
                  {links.map((link, i) => (
                    <div key={i} className="flex gap-2 items-center">
                      <div className="flex-1 space-y-2">
                        <input value={link.label} onChange={e => updateLink(i, 'label', e.target.value)}
                          placeholder="Button Label"
                          className="w-full border border-border rounded-xl px-3 py-2 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
                        <input value={link.url} onChange={e => updateLink(i, 'url', e.target.value)}
                          placeholder="https://..."
                          className="w-full border border-border rounded-xl px-3 py-2 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
                      </div>
                      <button onClick={() => removeLink(i)} className="text-muted hover:text-red-500 transition-colors text-lg flex-shrink-0">×</button>
                    </div>
                  ))}
                </div>
                <button onClick={addLink} className="w-full border border-dashed border-border py-2.5 rounded-xl text-sm text-muted font-body hover:border-charcoal hover:text-charcoal transition-colors">
                  + Add Link
                </button>
              </div>

              <button className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors">
                Publish My Page →
              </button>
            </div>

            {/* Live Preview */}
            <div className="lg:sticky lg:top-24 h-fit">
              <h2 className="font-semibold text-sm font-body mb-4 text-muted uppercase tracking-wider font-mono">Live Preview</h2>
              <div className={`rounded-2xl p-8 min-h-96 ${t.bg} border border-border`}>
                {/* Avatar placeholder */}
                <div className="text-center mb-6">
                  <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center text-3xl ${t.btn}`}>
                    {name.charAt(0).toUpperCase()}
                  </div>
                  <h3 className={`font-display text-xl font-bold ${t.text}`}>{name}</h3>
                  <p className={`text-sm mt-1 font-body opacity-70 ${t.text}`}>{bio}</p>
                </div>

                <div className="space-y-3">
                  {links.map((link, i) => (
                    <a key={i} href={link.url || '#'}
                      className={`block w-full py-3 px-6 rounded-full text-sm font-medium text-center font-body transition-opacity hover:opacity-80 ${t.btn}`}>
                      {link.label || 'Untitled Link'}
                    </a>
                  ))}
                </div>

                <p className={`text-center text-xs mt-8 opacity-40 font-mono ${t.text}`}>
                  creatornest.app/{name.toLowerCase().replace(/\s/g, '')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
