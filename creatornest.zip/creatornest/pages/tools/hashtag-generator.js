import Head from 'next/head'
import { useState } from 'react'
import Link from 'next/link'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const platforms = ['Instagram', 'TikTok', 'YouTube', 'Twitter / X', 'LinkedIn']
const niches = ['Lifestyle', 'Tech', 'Food', 'Travel', 'Fitness', 'Fashion', 'Business', 'Gaming', 'Beauty', 'Education']

export default function HashtagGenerator() {
  const [platform, setPlatform] = useState('Instagram')
  const [niche, setNiche] = useState('')
  const [topic, setTopic] = useState('')
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)

  const generate = async () => {
    if (!topic.trim()) return
    setLoading(true)
    setResult(null)
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 800,
          messages: [{
            role: 'user',
            content: `Generate hashtags for ${platform} about "${topic}"${niche ? ` in the ${niche} niche` : ''}.
            Return ONLY a JSON object, no markdown:
            {
              "high_volume": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5"],
              "medium_volume": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5", "#tag6", "#tag7"],
              "niche_specific": ["#tag1", "#tag2", "#tag3", "#tag4", "#tag5", "#tag6", "#tag7", "#tag8"],
              "trending": ["#tag1", "#tag2", "#tag3"]
            }`
          }]
        })
      })
      const data = await response.json()
      const text = data.content?.[0]?.text || '{}'
      const clean = text.replace(/```json|```/g, '').trim()
      setResult(JSON.parse(clean))
    } catch {
      setResult(null)
    }
    setLoading(false)
  }

  const allHashtags = result
    ? [...(result.high_volume || []), ...(result.medium_volume || []), ...(result.niche_specific || []), ...(result.trending || [])].join(' ')
    : ''

  const copyAll = () => {
    navigator.clipboard.writeText(allHashtags)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <>
      <Head><title>Hashtag Generator — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="mb-12">
            <Link href="/tools" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Tools</Link>
            <h1 className="font-display text-4xl font-bold mt-4 mb-2">Hashtag Generator #️⃣</h1>
            <p className="text-muted font-body">Find the best hashtags to maximize your reach and discoverability.</p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-8 mb-8">
            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">Platform</label>
              <div className="flex flex-wrap gap-2">
                {platforms.map(p => (
                  <button key={p} onClick={() => setPlatform(p)}
                    className={`px-4 py-2 rounded-full text-sm font-body transition-all ${platform === p ? 'bg-charcoal text-cream' : 'bg-highlight border border-border text-muted hover:border-charcoal'}`}>{p}</button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">Your Niche (optional)</label>
              <div className="flex flex-wrap gap-2">
                {niches.map(n => (
                  <button key={n} onClick={() => setNiche(niche === n ? '' : n)}
                    className={`px-4 py-2 rounded-full text-sm font-body transition-all ${niche === n ? 'bg-charcoal text-cream' : 'bg-highlight border border-border text-muted hover:border-charcoal'}`}>{n}</button>
                ))}
              </div>
            </div>

            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">What is your post about?</label>
              <input
                value={topic}
                onChange={e => setTopic(e.target.value)}
                placeholder="e.g. Sunrise yoga session on the beach..."
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors"
              />
            </div>

            <button onClick={generate} disabled={loading || !topic.trim()}
              className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
              {loading ? 'Generating hashtags...' : 'Generate Hashtags →'}
            </button>
          </div>

          {result && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="font-display text-xl font-semibold">Your Hashtags</h2>
                <button onClick={copyAll} className="text-xs font-mono text-muted hover:text-charcoal transition-colors bg-highlight border border-border px-4 py-2 rounded-full">
                  {copied ? '✓ Copied!' : 'Copy All'}
                </button>
              </div>

              {[
                { key: 'high_volume', label: 'High Volume', desc: 'Millions of posts — great for visibility' },
                { key: 'trending', label: 'Trending Now', desc: 'Currently gaining traction' },
                { key: 'medium_volume', label: 'Mid Range', desc: 'Balanced reach and competition' },
                { key: 'niche_specific', label: 'Niche Specific', desc: 'Targeted audience, higher engagement' },
              ].map(group => (
                result[group.key]?.length > 0 && (
                  <div key={group.key} className="bg-white border border-border rounded-2xl p-6">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-sm font-semibold font-body">{group.label}</span>
                    </div>
                    <p className="text-xs text-muted font-body mb-4">{group.desc}</p>
                    <div className="flex flex-wrap gap-2">
                      {result[group.key].map(tag => (
                        <span key={tag} onClick={() => { navigator.clipboard.writeText(tag) }}
                          className="bg-highlight border border-border text-charcoal text-xs px-3 py-1.5 rounded-full font-mono cursor-pointer hover:bg-charcoal hover:text-cream transition-all">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}
