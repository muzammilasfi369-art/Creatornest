import Head from 'next/head'
import Link from 'next/link'
import { useState } from 'react'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const platforms = ['Instagram', 'TikTok', 'YouTube', 'Twitter / X', 'LinkedIn', 'Facebook']
const tones = ['Casual & Fun', 'Professional', 'Inspirational', 'Witty & Humorous', 'Educational', 'Storytelling']

export default function CaptionWriter() {
  const [platform, setPlatform] = useState('Instagram')
  const [tone, setTone] = useState('Casual & Fun')
  const [topic, setTopic] = useState('')
  const [captions, setCaptions] = useState([])
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(null)

  const generateCaptions = async () => {
    if (!topic.trim()) return
    setLoading(true)
    setCaptions([])
    try {
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `Generate 3 different ${tone} captions for ${platform} about: "${topic}". 
            Format as JSON array only, no markdown, no extra text:
            [{"caption": "...", "hashtags": "..."}, ...]
            Each caption should be optimized for ${platform} and include relevant emojis. Keep hashtags separate.`
          }]
        })
      })
      const data = await response.json()
      const text = data.content?.[0]?.text || '[]'
      const clean = text.replace(/```json|```/g, '').trim()
      const parsed = JSON.parse(clean)
      setCaptions(parsed)
    } catch {
      setCaptions([{ caption: 'Something went wrong. Please try again.', hashtags: '' }])
    }
    setLoading(false)
  }

  const copyText = (text, index) => {
    navigator.clipboard.writeText(text)
    setCopied(index)
    setTimeout(() => setCopied(null), 2000)
  }

  return (
    <>
      <Head>
        <title>AI Caption Writer — CreatorNest</title>
      </Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-3xl mx-auto">
          <div className="mb-12">
            <Link href="/tools" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Tools</Link>
            <h1 className="font-display text-4xl font-bold mt-4 mb-2">AI Caption Writer ✍️</h1>
            <p className="text-muted font-body">Generate scroll-stopping captions for any platform in seconds.</p>
          </div>

          {/* Form */}
          <div className="bg-white border border-border rounded-2xl p-8 mb-8">
            {/* Platform */}
            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">Platform</label>
              <div className="flex flex-wrap gap-2">
                {platforms.map(p => (
                  <button key={p} onClick={() => setPlatform(p)}
                    className={`px-4 py-2 rounded-full text-sm font-body transition-all ${
                      platform === p ? 'bg-charcoal text-cream' : 'bg-highlight border border-border text-muted hover:border-charcoal'
                    }`}>{p}</button>
                ))}
              </div>
            </div>

            {/* Tone */}
            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">Tone</label>
              <div className="flex flex-wrap gap-2">
                {tones.map(t => (
                  <button key={t} onClick={() => setTone(t)}
                    className={`px-4 py-2 rounded-full text-sm font-body transition-all ${
                      tone === t ? 'bg-charcoal text-cream' : 'bg-highlight border border-border text-muted hover:border-charcoal'
                    }`}>{t}</button>
                ))}
              </div>
            </div>

            {/* Topic */}
            <div className="mb-6">
              <label className="block text-sm font-semibold font-body mb-3">What's your post about?</label>
              <textarea
                value={topic}
                onChange={e => setTopic(e.target.value)}
                placeholder="e.g. Morning routine for productivity, New recipe I tried, Travel vlog in Tokyo..."
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body resize-none h-28 focus:outline-none focus:border-charcoal transition-colors"
              />
            </div>

            <button
              onClick={generateCaptions}
              disabled={loading || !topic.trim()}
              className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Generating captions...' : 'Generate 3 Captions →'}
            </button>
          </div>

          {/* Results */}
          {captions.length > 0 && (
            <div className="space-y-4">
              <h2 className="font-display text-xl font-semibold">Your Captions</h2>
              {captions.map((c, i) => (
                <div key={i} className="bg-white border border-border rounded-2xl p-6">
                  <div className="flex justify-between items-start gap-4 mb-4">
                    <span className="text-xs font-mono text-muted bg-highlight px-3 py-1 rounded-full">Option {i + 1}</span>
                    <button
                      onClick={() => copyText(`${c.caption}\n\n${c.hashtags}`, i)}
                      className="text-xs font-mono text-muted hover:text-charcoal transition-colors flex-shrink-0"
                    >
                      {copied === i ? '✓ Copied!' : 'Copy all'}
                    </button>
                  </div>
                  <p className="text-charcoal font-body text-sm leading-relaxed mb-4">{c.caption}</p>
                  {c.hashtags && (
                    <p className="text-muted font-body text-xs leading-relaxed">{c.hashtags}</p>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </main>
      <Footer />
    </>
  )
}

impo