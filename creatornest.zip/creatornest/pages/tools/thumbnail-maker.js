import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const templates = [
  { name: 'Bold & Bright', bg: 'from-yellow-400 to-orange-500', textColor: 'text-white' },
  { name: 'Dark Cinematic', bg: 'from-gray-900 to-gray-700', textColor: 'text-white' },
  { name: 'Clean Minimal', bg: 'from-white to-gray-100', textColor: 'text-gray-900' },
  { name: 'Gradient Pro', bg: 'from-purple-500 to-blue-600', textColor: 'text-white' },
  { name: 'Red Alert', bg: 'from-red-500 to-red-700', textColor: 'text-white' },
  { name: 'Nature Vibe', bg: 'from-green-400 to-teal-600', textColor: 'text-white' },
]

export default function ThumbnailMaker() {
  return (
    <>
      <Head><title>Thumbnail Maker — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="mb-12">
            <Link href="/tools" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Tools</Link>
            <h1 className="font-display text-4xl font-bold mt-4 mb-2">Thumbnail Maker 🖼️</h1>
            <p className="text-muted font-body">Design professional YouTube thumbnails. Choose a template to get started.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {templates.map(t => (
              <div key={t.name} className="tool-card border border-border rounded-2xl overflow-hidden cursor-pointer">
                <div className={`h-40 bg-gradient-to-br ${t.bg} flex items-center justify-center`}>
                  <div className="text-center px-4">
                    <p className={`font-display text-xl font-bold ${t.textColor}`}>YOUR TITLE HERE</p>
                    <p className={`text-sm mt-1 ${t.textColor} opacity-70 font-body`}>Subtitle text</p>
                  </div>
                </div>
                <div className="bg-white p-4 flex justify-between items-center">
                  <span className="text-sm font-semibold font-body">{t.name}</span>
                  <span className="text-xs text-muted font-mono bg-highlight px-3 py-1 rounded-full">Use Template</span>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-highlight border border-border rounded-2xl p-8 text-center">
            <span className="text-4xl mb-4 block">🎨</span>
            <h2 className="font-display text-2xl font-bold mb-3">Full editor coming soon</h2>
            <p className="text-muted font-body max-w-md mx-auto mb-6">
              A full drag-and-drop thumbnail editor with text, image layers, icons, and export is in development. Join the waitlist to be first!
            </p>
            <button className="bg-charcoal text-cream px-6 py-3 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors">
              Join Waitlist
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
