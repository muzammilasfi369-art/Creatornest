import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

const tools = [
  { icon: '✍️', title: 'AI Caption Writer', desc: 'Generate scroll-stopping captions for every platform instantly.', href: '/tools/caption-writer', tag: 'AI' },
  { icon: '#️⃣', title: 'Hashtag Generator', desc: 'Find high-performing hashtags tailored to your niche.', href: '/tools/hashtag-generator', tag: 'Growth' },
  { icon: '🖼️', title: 'Thumbnail Maker', desc: 'Design professional YouTube thumbnails with ease.', href: '/tools/thumbnail-maker', tag: 'Design' },
  { icon: '🔗', title: 'Link in Bio Builder', desc: 'Build a beautiful bio link page for all your links.', href: '/tools/link-in-bio', tag: 'Pages' },
  { icon: '📝', title: 'Script Writer', desc: 'AI-powered YouTube & podcast script generator.', href: '/tools/script-writer', tag: 'AI' },
  { icon: '🎨', title: 'Brand Kit Generator', desc: 'Create a consistent brand palette, fonts & logo.', href: '/tools/brand-kit', tag: 'Design' },
  { icon: '📧', title: 'Newsletter Builder', desc: 'Write and send creator newsletters to your fans.', href: '/tools/newsletter', tag: 'Email' },
  { icon: '💬', title: 'Comment Reply AI', desc: 'Generate smart replies to your comments in bulk.', href: '/tools/comment-reply', tag: 'AI' },
]

export default function ToolsPage() {
  return (
    <>
      <Head>
        <title>Creator Tools — CreatorNest</title>
        <meta name="description" content="All the tools you need to grow as a content creator." />
      </Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-xs font-mono text-muted uppercase tracking-widest">Creator Toolkit</span>
            <h1 className="font-display text-5xl font-bold mt-3 mb-4">All your tools, one place</h1>
            <p className="text-muted font-body max-w-xl mx-auto">Stop juggling 10 apps. Everything you need to create, grow, and monetize is right here.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {tools.map(tool => (
              <Link key={tool.title} href={tool.href}>
                <div className="tool-card bg-white border border-border rounded-2xl p-8 cursor-pointer h-full">
                  <div className="flex items-start justify-between mb-4">
                    <span className="text-3xl">{tool.icon}</span>
                    <span className="text-xs bg-highlight text-muted px-3 py-1 rounded-full font-mono">{tool.tag}</span>
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-2">{tool.title}</h3>
                  <p className="text-sm text-muted font-body leading-relaxed">{tool.desc}</p>
                  <div className="mt-5 text-sm font-medium font-body text-charcoal flex items-center gap-1">Use tool →</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
