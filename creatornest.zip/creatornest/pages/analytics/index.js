import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const stats = [
  { label: 'Total Followers', value: '284,930', change: '+12.4%', up: true },
  { label: 'Total Views', value: '4.2M', change: '+8.1%', up: true },
  { label: 'Avg Engagement', value: '5.7%', change: '+2.3%', up: true },
  { label: 'Revenue Est.', value: '$3,240', change: '-1.2%', up: false },
]

const platformStats = [
  { platform: 'YouTube', icon: '▶️', followers: '142K', views: '2.1M', engagement: '4.2%', growth: '+5.3%' },
  { platform: 'Instagram', icon: '📸', followers: '89K', views: '980K', engagement: '7.8%', growth: '+14.2%' },
  { platform: 'TikTok', icon: '🎵', followers: '43K', views: '890K', engagement: '9.1%', growth: '+31.5%' },
  { platform: 'Twitter / X', icon: '🐦', followers: '10.9K', views: '230K', engagement: '2.4%', growth: '+3.1%' },
]

const topContent = [
  { title: 'How I make $10K/month as a creator', platform: 'YouTube', views: '890K', engagement: '8.2%' },
  { title: 'Morning routine that changed my life', platform: 'Instagram', views: '540K', engagement: '11.4%' },
  { title: 'Day in the life of a full-time creator', platform: 'TikTok', views: '320K', engagement: '14.2%' },
  { title: 'My camera gear for under $500', platform: 'YouTube', views: '290K', engagement: '6.8%' },
]

export default function Analytics() {
  return (
    <>
      <Head><title>Analytics Dashboard — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="mb-10">
            <Link href="/" className="text-xs text-muted font-mono hover:text-charcoal transition-colors">← Back to Home</Link>
            <div className="flex flex-col md:flex-row md:items-center justify-between mt-4 gap-4">
              <div>
                <h1 className="font-display text-4xl font-bold mb-1">Analytics 📊</h1>
                <p className="text-muted font-body">All your metrics across every platform, in one place.</p>
              </div>
              <div className="flex gap-2">
                {['7 days', '30 days', '90 days', '1 year'].map(r => (
                  <button key={r} className={`px-4 py-2 rounded-full text-xs font-mono border transition-all ${r === '30 days' ? 'bg-charcoal text-cream border-charcoal' : 'border-border text-muted hover:border-charcoal'}`}>{r}</button>
                ))}
              </div>
            </div>
          </div>

          {/* Overview Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            {stats.map(s => (
              <div key={s.label} className="bg-white border border-border rounded-2xl p-6">
                <p className="text-xs text-muted font-mono mb-2">{s.label}</p>
                <p className="font-display text-2xl font-bold mb-1">{s.value}</p>
                <span className={`text-xs font-mono ${s.up ? 'text-green-600' : 'text-red-500'}`}>{s.change} this month</span>
              </div>
            ))}
          </div>

          {/* Chart placeholder */}
          <div className="bg-white border border-border rounded-2xl p-8 mb-8">
            <h2 className="font-display text-xl font-semibold mb-6">Views Over Time</h2>
            <div className="h-48 flex items-end gap-2">
              {[40, 65, 45, 80, 60, 90, 75, 95, 70, 85, 100, 88, 72, 95, 110, 98, 115, 105, 120, 100, 130, 118, 140, 125, 145, 135, 150, 140, 155, 148].map((h, i) => (
                <div key={i} className="flex-1 bg-charcoal rounded-t-sm transition-all hover:bg-muted" style={{ height: `${h * 0.6}%`, opacity: 0.7 + (i / 100) }} />
              ))}
            </div>
            <div className="flex justify-between text-xs text-muted font-mono mt-3">
              <span>30 days ago</span><span>15 days ago</span><span>Today</span>
            </div>
          </div>

          {/* Per Platform */}
          <div className="mb-8">
            <h2 className="font-display text-xl font-semibold mb-4">Platform Breakdown</h2>
            <div className="bg-white border border-border rounded-2xl overflow-hidden">
              <table className="w-full">
                <thead className="bg-highlight border-b border-border">
                  <tr>
                    {['Platform', 'Followers', 'Views', 'Engagement', 'Growth'].map(h => (
                      <th key={h} className="text-left px-6 py-4 text-xs font-mono text-muted uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {platformStats.map(p => (
                    <tr key={p.platform} className="hover:bg-highlight transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span>{p.icon}</span>
                          <span className="text-sm font-semibold font-body">{p.platform}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm font-mono text-charcoal">{p.followers}</td>
                      <td className="px-6 py-4 text-sm font-mono text-charcoal">{p.views}</td>
                      <td className="px-6 py-4 text-sm font-mono text-charcoal">{p.engagement}</td>
                      <td className="px-6 py-4">
                        <span className="text-xs font-mono text-green-600 bg-green-50 px-2 py-1 rounded-full">{p.growth}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Top Content */}
          <div>
            <h2 className="font-display text-xl font-semibold mb-4">Top Performing Content</h2>
            <div className="space-y-3">
              {topContent.map((c, i) => (
                <div key={i} className="bg-white border border-border rounded-xl px-6 py-4 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-0">
                    <span className="text-2xl font-display font-bold text-border w-6 flex-shrink-0">{i + 1}</span>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold font-body truncate">{c.title}</p>
                      <p className="text-xs text-muted font-mono mt-0.5">{c.platform}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 flex-shrink-0">
                    <div className="text-right">
                      <p className="text-sm font-mono font-semibold">{c.views}</p>
                      <p className="text-xs text-muted font-mono">views</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-mono font-semibold text-green-600">{c.engagement}</p>
                      <p className="text-xs text-muted font-mono">engage</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
