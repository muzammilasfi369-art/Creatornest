import Head from 'next/head'
import Link from 'next/link'
import { useState } from 'react'
import Navbar from '../../components/Navbar'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')

  return (
    <>
      <Head><title>Sign In — CreatorNest</title></Head>
      <Navbar />
      <main className="min-h-screen flex items-center justify-center px-6 pt-16">
        <div className="w-full max-w-md">
          <div className="text-center mb-10">
            <h1 className="font-display text-4xl font-bold mb-2">Welcome back</h1>
            <p className="text-muted font-body text-sm">Sign in to your CreatorNest account</p>
          </div>

          <div className="bg-white border border-border rounded-2xl p-8">
            <div className="mb-4">
              <label className="block text-sm font-semibold font-body mb-2">Email</label>
              <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
            </div>
            <div className="mb-6">
              <div className="flex justify-between mb-2">
                <label className="text-sm font-semibold font-body">Password</label>
                <Link href="#" className="text-xs text-muted hover:text-charcoal font-body transition-colors">Forgot password?</Link>
              </div>
              <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full border border-border rounded-xl px-4 py-3 text-sm font-body focus:outline-none focus:border-charcoal transition-colors" />
            </div>
            <button className="w-full bg-charcoal text-cream py-3.5 rounded-full text-sm font-medium font-body hover:bg-accent transition-colors">
              Sign In
            </button>
            <p className="text-center text-sm text-muted font-body mt-6">
              Don't have an account?{' '}
              <Link href="/signup" className="text-charcoal font-semibold hover:underline">Sign up free</Link>
            </p>
          </div>
        </div>
      </main>
    </>
  )
}
