import Head from 'next/head'
import Link from 'next/link'
import Navbar from '../../components/Navbar'
import Footer from '../../components/Footer'

const plans = [
  {
    name: 'Free', price: '$0', period: 'forever', desc: 'Perfect to get started',
    features: ['5 AI captions/month', 'Hashtag generator (basic)', '1 scheduled post/day', 'Link in bio page', '1 platform connected', 'Community support'],
    cta: 'Start Free', highlight: false,
  },
  {
    name: 'Pro', price: '$12', period: '/month', desc: 'For growing creators',
    features: ['Unlimited AI captions', 'Advanced hashtag analytics', '50 scheduled posts/day', 'Thumbnail maker', 'Analytics dashboard', '5 platforms connected', 'Priority email support'],
    cta: 'Start 7-Day Free Trial', highlight: true,
  },
  {
    name: 'Agency', price: '$39', period: '/month', desc: 'For teams & agencies',
    features: ['Everything in Pro', 'Manage 10+ accounts', 'Team collaboration tools', 'White-label PDF reports', 'API access', 'All platforms connected', 'Dedicated account manager'],
    cta: 'Contact Sales', highlight: false,
  },
]

const faqs = [
  { q: 'Is the free plan really free forever?', a: 'Yes! Our free plan has no time limit. You can use CreatorNest free forever with the included features.' },
  { q: 'Can I cancel anytime?', a: 'Absolutely. No contracts, no lock-in. Cancel anytime from your account settings.' },
  { q: 'Do I need a credit card for the free trial?', a: 'No credit card required for the free plan. For the Pro trial, we ask for card details but won\'t charge you until the trial ends.' },
  { q: 'Which platforms are supported?', a: 'We support YouTube, Instagram, TikTok, Facebook, Twitter/X, LinkedIn, Pinterest, and Snapchat.' },
  { q: 'How does the AI caption writer work?', a: 'Our AI is powered by advanced language models. Just describe your post and it generates captions tailored to your platform and tone.' },
]

export default function Pricing() {
  return (
    <>
      <Head><title>Pricing — CreatorNest</title></Head>
      <Navbar />
      <main className="pt-28 pb-24 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="text-xs font-mono text-muted uppercase tracking-widest">Pricing</span>
            <h1 className="font-display text-5xl font-bold mt-3 mb-4">Simple, honest pricing</h1>
            <p className="text-muted font-body max-w-xl mx-auto">Start free. Upgrade when you're ready. No hidden fees.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24 items-start">
            {plans.map(plan => (
              <div key={plan.name} className={`rounded-2xl p-8 ${plan.highlight ? 'bg-charcoal text-cream ring-2 ring-charcoal md:scale-105' : 'bg-white border border-border'}`}>
                {plan.highlight && <div className="text-xs font-mono bg-white text-charcoal px-3 py-1 rounded-full inline-block mb-4">Most Popular</div>}
                <h3 className={`font-display text-2xl font-bold ${plan.highlight ? 'text-cream' : 'text-charcoal'}`}>{plan.name}</h3>
                <p className={`text-sm mt-1 font-body mb-6 ${plan.highlight ? 'text-gray-400' : 'text-muted'}`}>{plan.desc}</p>
                <div className="mb-8">
                  <span className={`font-display text-4xl font-bold ${plan.highlight ? 'text-cream' : 'text-charcoal'}`}>{plan.price}</span>
                  <span className={`text-sm font-body ml-1 ${plan.highlight ? 'text-gray-400' : 'text-muted'}`}>{plan.period}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map(f => (
                    <li key={f} className={`flex items-center gap-3 text-sm font-body ${plan.highlight ? 'text-gray-300' : 'text-muted'}`}>
                      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-xs flex-shrink-0 ${plan.highlight ? 'bg-white text-charcoal' : 'bg-charcoal text-cream'}`}>✓</span>
                      {f}
                    </li>
                  ))}
                </ul>
                <Link href="/signup" className={`block text-center py-3.5 rounded-full text-sm font-medium font-body transition-colors ${plan.highlight ? 'bg-white text-charcoal hover:bg-gray-100' : 'bg-charcoal text-cream hover:bg-accent'}`}>
                  {plan.cta}
                </Link>
              </div>
            ))}
          </div>

          {/* FAQ */}
          <div className="max-w-2xl mx-auto">
            <h2 className="font-display text-3xl font-bold text-center mb-10">Frequently Asked Questions</h2>
            <div className="space-y-4">
              {faqs.map(faq => (
                <div key={faq.q} className="bg-white border border-border rounded-2xl px-6 py-5">
                  <h3 className="font-semibold text-sm font-body mb-2">{faq.q}</h3>
                  <p className="text-sm text-muted font-body leading-relaxed">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
