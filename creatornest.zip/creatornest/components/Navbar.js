import { useState, useEffect } from 'react'
import Link from 'next/link'

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 nav-blur transition-all duration-300 ${
      scrolled ? 'bg-white/90 border-b border-border' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <span className="font-display text-xl font-700 text-charcoal tracking-tight">
            Creator<span className="text-muted">Nest</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <Link href="/tools" className="text-sm text-muted hover:text-charcoal transition-colors font-body">Tools</Link>
          <Link href="/scheduler" className="text-sm text-muted hover:text-charcoal transition-colors font-body">Scheduler</Link>
          <Link href="/analytics" className="text-sm text-muted hover:text-charcoal transition-colors font-body">Analytics</Link>
          <Link href="/pricing" className="text-sm text-muted hover:text-charcoal transition-colors font-body">Pricing</Link>
        </div>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <Link href="/login" className="text-sm text-muted hover:text-charcoal transition-colors font-body">
            Sign in
          </Link>
          <Link href="/signup" className="bg-charcoal text-cream text-sm px-4 py-2 rounded-full hover:bg-accent transition-colors font-body">
            Get Started Free
          </Link>
        </div>

        {/* Mobile Menu Toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-1"
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span className={`block w-5 h-0.5 bg-charcoal transition-all ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
          <span className={`block w-5 h-0.5 bg-charcoal transition-all ${menuOpen ? 'opacity-0' : ''}`} />
          <span className={`block w-5 h-0.5 bg-charcoal transition-all ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-border px-6 py-6 flex flex-col gap-4">
          <Link href="/tools" className="text-sm text-charcoal font-body" onClick={() => setMenuOpen(false)}>Tools</Link>
          <Link href="/scheduler" className="text-sm text-charcoal font-body" onClick={() => setMenuOpen(false)}>Scheduler</Link>
          <Link href="/analytics" className="text-sm text-charcoal font-body" onClick={() => setMenuOpen(false)}>Analytics</Link>
          <Link href="/pricing" className="text-sm text-charcoal font-body" onClick={() => setMenuOpen(false)}>Pricing</Link>
          <hr className="border-border" />
          <Link href="/login" className="text-sm text-muted font-body" onClick={() => setMenuOpen(false)}>Sign in</Link>
          <Link href="/signup" className="bg-charcoal text-cream text-sm px-4 py-2 rounded-full text-center font-body" onClick={() => setMenuOpen(false)}>Get Started Free</Link>
        </div>
      )}
    </nav>
  )
}
