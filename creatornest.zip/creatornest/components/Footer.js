import Link from 'next/link'

export default function Footer() {
  return (
    <footer className="bg-charcoal text-cream mt-24">
      <div className="max-w-7xl mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Brand */}
          <div className="col-span-1">
            <span className="font-display text-2xl font-bold">
              Creator<span className="text-muted">Nest</span>
            </span>
            <p className="text-sm text-gray-400 mt-3 leading-relaxed font-body">
              The all-in-one platform built for the next generation of content creators.
            </p>
          </div>

          {/* Tools */}
          <div>
            <h4 className="text-sm font-semibold mb-4 font-body tracking-wider uppercase text-gray-300">Tools</h4>
            <ul className="space-y-2">
              {['AI Caption Writer', 'Hashtag Generator', 'Thumbnail Maker', 'Scheduler', 'Analytics'].map(t => (
                <li key={t}>
                  <Link href="/tools" className="text-sm text-gray-400 hover:text-cream transition-colors font-body">{t}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold mb-4 font-body tracking-wider uppercase text-gray-300">Company</h4>
            <ul className="space-y-2">
              {['About', 'Blog', 'Careers', 'Press'].map(t => (
                <li key={t}>
                  <Link href="#" className="text-sm text-gray-400 hover:text-cream transition-colors font-body">{t}</Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h4 className="text-sm font-semibold mb-4 font-body tracking-wider uppercase text-gray-300">Legal</h4>
            <ul className="space-y-2">
              {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map(t => (
                <li key={t}>
                  <Link href="#" className="text-sm text-gray-400 hover:text-cream transition-colors font-body">{t}</Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-gray-500 font-body">© 2025 CreatorNest. All rights reserved.</p>
          <div className="flex gap-6">
            {['Twitter', 'Instagram', 'YouTube', 'LinkedIn'].map(s => (
              <Link key={s} href="#" className="text-sm text-gray-500 hover:text-cream transition-colors font-body">{s}</Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
